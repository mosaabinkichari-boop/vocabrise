# VocabRise — English Vocabulary Trainer

Première version Android native (Kotlin + Jetpack Compose).

## Fonctionnalités incluses
- Accueil et mot du jour
- 12 mots de vocabulaire avec définition, traduction française et exemple
- Cartes mémoire précédent/suivant
- Quiz de 8 questions à choix multiples avec score
- Liste locale de mots favoris
- Interface en anglais, avec aide en français
- Fonctionne hors ligne et ne demande aucune clé API

## Ouvrir le projet
1. Télécharge et décompresse `VocabRise.zip`.
2. Installe Android Studio sur un ordinateur.
3. Ouvre le dossier `VocabRise` dans Android Studio.
4. Accepte la synchronisation Gradle et installe le SDK Android demandé.
5. Lance l'application sur un téléphone Android connecté en USB ou sur un émulateur.

## Limites de cette version
- C'est un prototype fonctionnel de départ, pas encore une version prête à publier.
- Les favoris et les progrès ne sont pas encore conservés après fermeture de l'application.
- Pas encore de publicité, d'achat intégré, d'analytics ni de rappels.
- Avant Google Play, il faut tester sur plusieurs appareils, améliorer l'accessibilité, créer les icônes/captures d'écran, remplir la fiche de confidentialité et vérifier les exigences actuelles de Google Play.
- Le numéro de version `targetSdk` et les dépendances devront être vérifiés/actualisés selon les exigences de Play Console au moment de publier.

## Prochaines étapes conseillées
1. Tester et corriger le prototype.
2. Ajouter la sauvegarde locale durable des favoris et des résultats.
3. Ajouter un catalogue de vocabulaire plus large et les niveaux A1–C1.
4. Préparer une politique de confidentialité et une fiche Play Store.
5. Intégrer AdMob uniquement après validation des règles, consentements et configuration du compte.
