package com.vocabrise.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF15233D)
private val Teal = Color(0xFF12B8A6)
private val Canvas = Color(0xFFF6F8FC)
private val Muted = Color(0xFF65728A)

data class Word(val word: String, val type: String, val definition: String, val french: String, val example: String)

private val words = listOf(
    Word("Achieve", "verb", "To succeed in doing something after effort.", "Réussir / accomplir", "She worked hard to achieve her goal."),
    Word("Reliable", "adjective", "Someone or something you can trust.", "Fiable", "He is a reliable friend."),
    Word("Improve", "verb", "To make something better.", "Améliorer", "I want to improve my English."),
    Word("Opportunity", "noun", "A situation that makes it possible to do something.", "Occasion / opportunité", "This job is a great opportunity."),
    Word("Confident", "adjective", "Feeling sure about your abilities.", "Confiant", "She feels confident before the exam."),
    Word("Avoid", "verb", "To stay away from something.", "Éviter", "Try to avoid making the same mistake."),
    Word("Effort", "noun", "The energy you use to do something.", "Effort", "Learning a language takes effort."),
    Word("Increase", "verb", "To become or make something larger.", "Augmenter", "Practice can increase your vocabulary."),
    Word("Manage", "verb", "To control or organize something successfully.", "Gérer", "I manage my time carefully."),
    Word("Accurate", "adjective", "Correct and without mistakes.", "Précis / exact", "Please give an accurate answer."),
    Word("Benefit", "noun", "A good or helpful result.", "Avantage / bénéfice", "Daily reading has many benefits."),
    Word("Develop", "verb", "To grow or make something more advanced.", "Développer", "She wants to develop new skills.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VocabRiseApp() }
    }
}

@Composable
fun VocabRiseApp() {
    var tab by remember { mutableStateOf("Home") }
    var index by remember { mutableIntStateOf(0) }
    var showAnswer by remember { mutableStateOf(false) }
    var quizIndex by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var finished by remember { mutableStateOf(false) }
    val saved = remember { mutableStateListOf<String>() }
    val quizWords = words.take(8)
    val current = words[index % words.size]

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Teal, secondary = Navy, background = Canvas, surface = Color.White)
    ) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Learn", "Quiz", "Saved").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(when (item) { "Home" -> "⌂"; "Learn" -> "▤"; "Quiz" -> "✓"; else -> "☆" }, fontSize = 20.sp) },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Teal, selectedTextColor = Teal)
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (tab) {
                    "Home" -> {
                        Text("VOCABRISE", color = Teal, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 13.sp)
                        Text("Build your English,\none word at a time.", color = Navy, fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
                        Text("Small daily practice. Real progress.", color = Muted, fontSize = 15.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard("12", "Starter words", Modifier.weight(1f))
                            StatCard("${saved.size}", "Saved words", Modifier.weight(1f))
                        }
                        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("WORD OF THE DAY", color = Color(0xFF8DE8DC), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                Text(current.word, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                                Text(current.definition, color = Color(0xFFE1E8F2), fontSize = 15.sp)
                                Text("“${current.example}”", color = Color.White, fontSize = 14.sp)
                                Button(onClick = { tab = "Learn"; showAnswer = false }, colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                                    Text("Start learning")
                                }
                            }
                        }
                        Text("Your learning path", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(Modifier.weight(1f)) { MiniAction("Flashcards", "Review words") { tab = "Learn" } }
                            Box(Modifier.weight(1f)) { MiniAction("Quick quiz", "Test yourself") { tab = "Quiz"; quizIndex = 0; score = 0; selected = null; finished = false } }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("Works offline • Free starter edition", color = Muted, fontSize = 12.sp)
                    }
                    "Learn" -> {
                        Header("Flashcards", "Learn meanings and examples.")
                        Text("WORD ${index + 1} OF ${words.size}", color = Teal, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                        Card(
                            modifier = Modifier.fillMaxWidth().weight(1f).clickable { showAnswer = !showAnswer },
                            shape = RoundedCornerShape(28.dp),
                            colors = CardDefaults.cardColors(containerColor = Navy)
                        ) {
                            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(if (showAnswer) current.type.uppercase() else "TAP TO REVEAL", color = Color(0xFF8DE8DC), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                Spacer(Modifier.height(16.dp))
                                Text(current.word, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                                if (showAnswer) {
                                    Spacer(Modifier.height(18.dp))
                                    Text(current.definition, color = Color.White, fontSize = 17.sp)
                                    Spacer(Modifier.height(10.dp))
                                    Text(current.french, color = Color(0xFF8DE8DC), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.height(14.dp))
                                    Text("“${current.example}”", color = Color(0xFFE1E8F2), fontSize = 14.sp)
                                } else {
                                    Spacer(Modifier.height(12.dp))
                                    Text("Think of the meaning, then tap this card.", color = Color(0xFFE1E8F2), fontSize = 14.sp)
                                }
                            }
                        }
                        OutlinedButton(onClick = { if (current.word in saved) saved.remove(current.word) else saved.add(current.word) }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (current.word in saved) "★ Saved to My Words" else "☆ Save this word")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(onClick = { index = (index - 1 + words.size) % words.size; showAnswer = false }, modifier = Modifier.weight(1f)) { Text("Previous") }
                            Button(onClick = { index = (index + 1) % words.size; showAnswer = false }, modifier = Modifier.weight(1f)) { Text("Next word") }
                        }
                    }
                    "Quiz" -> {
                        Header("Quick Quiz", "Choose the correct meaning.")
                        if (finished) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("QUIZ COMPLETE", color = Teal, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                    Text("$score / ${quizWords.size}", color = Navy, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                                    Text("Keep practising to remember more words.", color = Muted)
                                    Button(onClick = { quizIndex = 0; score = 0; selected = null; finished = false }) { Text("Try again") }
                                }
                            }
                        } else {
                            val q = quizWords[quizIndex]
                            val choices = remember(quizIndex) {
                                (listOf(q) + words.filter { it.word != q.word }.shuffled().take(3)).shuffled()
                            }
                            Text("QUESTION ${quizIndex + 1} OF ${quizWords.size}", color = Teal, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                            Text(q.word, color = Navy, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("What does this word mean?", color = Muted)
                            choices.forEach { option ->
                                val isChosen = selected == option.word
                                val isCorrect = option.word == q.word
                                Card(
                                    modifier = Modifier.fillMaxWidth().clickable(enabled = selected == null) { selected = option.word; if (isCorrect) score++ },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = when {
                                        selected != null && isCorrect -> Color(0xFFDDF7EF)
                                        selected != null && isChosen && !isCorrect -> Color(0xFFFFE8E7)
                                        else -> Color.White
                                    })
                                ) {
                                    Text(option.definition, modifier = Modifier.padding(16.dp), color = Navy, fontSize = 14.sp)
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            if (selected != null) {
                                Text(if (selected == q.word) "Correct! Well done." else "Correct answer: ${q.definition}", color = if (selected == q.word) Color(0xFF16805D) else Color(0xFFB64C45), fontWeight = FontWeight.SemiBold)
                                Button(onClick = {
                                    if (quizIndex + 1 >= quizWords.size) finished = true
                                    else { quizIndex++; selected = null }
                                }, modifier = Modifier.fillMaxWidth()) { Text(if (quizIndex + 1 == quizWords.size) "See results" else "Next question") }
                            }
                        }
                    }
                    "Saved" -> {
                        Header("My Words", "Your personal revision list.")
                        if (saved.isEmpty()) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("No saved words yet", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("Open Flashcards and tap “Save this word” to build your list.", color = Muted)
                                    Button(onClick = { tab = "Learn" }) { Text("Explore words") }
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(words.filter { it.word in saved }) { word ->
                                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                            Text(word.word, color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                            Text(word.definition, color = Muted)
                                            Text(word.french, color = Teal, fontWeight = FontWeight.SemiBold)
                                            TextButton(onClick = { saved.remove(word.word) }) { Text("Remove") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(title: String, subtitle: String) {
    Text("VOCABRISE", color = Teal, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 12.sp)
    Text(title, color = Navy, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    Text(subtitle, color = Muted, fontSize = 14.sp)
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, color = Navy, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MiniAction(title: String, subtitle: String, onClick: () -> Unit) {
    Card(modifier = Modifier.weightlessClickArea(onClick), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Navy, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

private fun Modifier.weightlessClickArea(onClick: () -> Unit): Modifier = this.fillMaxWidth().clickable { onClick() }
